# Hold response to Forescout
response = {}

response["succeeded"] = True
response["result_msg"] = "Successfully deleted data!"